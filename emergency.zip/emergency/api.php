<?php
include "connection.php";

session_start(); 


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM userlogin WHERE username = '$username' AND pass = '$password'";
    $result = $mysqli->query($sql);

    if ($result->num_rows == 1) {

        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit;
    } else {

        echo "<h2>Login failed. Invalid username or password.</h2>";
    }
}

if (isset($_POST['save'])){
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $number = $_POST['number'];
    $address = $_POST['address'];
    $age = $_POST['age'];

    $mysqli->query("INSERT INTO infos (firstname,lastname,number,address,age) VALUES('$firstname','$lastname','$number','$address','$age')") or die($mysqli->error);
    header("Location: index.php");
}

if (isset($_POST['update'])){
    $id = $_POST['id'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $number = $_POST['number'];
    $address = $_POST['address'];
    $age = $_POST['age'];

    $mysqli->query("UPDATE infos SET firstname = '$firstname', lastname = '$lastname', number = '$number', address = '$address', age='$age' WHERE user_id=$id") or die($mysqli->error);
    header("Location: index.php");
}
if (isset($_GET['delete'])){
    $id = $_GET['delete'];
    $mysqli->query("DELETE FROM infos WHERE user_id=$id") or die($mysqli->error);
    header("Location: index.php");
}
?>