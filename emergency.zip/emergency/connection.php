<?php

$mysqli = new mysqli('localhost','root','','contacts');

if ($mysqli->connect_error){
    die("Connection failed: " . $mysqli->connect_error);
}
echo " ";
?>