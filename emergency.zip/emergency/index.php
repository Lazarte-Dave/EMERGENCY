<?php include 'connection.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BASIC CRUD</title>
</head>
<body>
    <h4>Input Credentials</h4>
    <form action="api.php" method="POST">
        <input type="text" name="firstname" placeholder="Enter Firstname"><br><br>
        <input type="text" name="number" placeholder="Enter Number"><br><br>
        <input type="text" name="address" placeholder="Enter Address"><br><br>
        <input type="text" name="age" placeholder="Enter Age"><br><br>
        <button type="submit" name="save">Add</button>
        <button href="login.php">Back</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Number</th>
                <th>Address</th>
                <th>Age</th>
                <th colspan="2">Actions</th>
            </tr>
        </thead>
        
        <tbody>
            <?php
            $result = $mysqli->query("SELECT * FROM infos") or die ($mysqli->error);
            while ($row = $result->fetch_assoc()): ?>
            
            <tr>
                <td><?php echo $row['firstname'];?></td>
                <td><?php echo $row['lastname'];?></td>
                <td><?php echo $row['number'];?></td>
                <td><?php echo $row['address'];?></td>
                <td><?php echo $row['age'];?></td>

                <td>
                    <a href="index.php?edit=<?php echo $row['user_id'];?>">Edit</a>
                    <a href="api.php?delete=<?php echo $row['user_id'];?>">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php
    if(isset($_GET['edit'])){
    $id = $_GET['edit'];
    $result = $mysqli->query("SELECT * FROM infos WHERE user_id=$id") or die($mysqli->error);
    $row = $result->fetch_assoc();
}
?>
<?php
if(isset($row)):?>
    <form action="api.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['user_id'];?>">
        <input type="text" name="firstname" value="<?php echo $row['firstname'];?>"required>
        <input type="text" name="lastname" value="<?php echo $row['lastname'];?>"required>
        <input type="text" name="number" value="<?php echo $row['number'];?>"required>
        <input type="text" name="address" value="<?php echo $row['address'];?>"required>
        <input type="text" name="age" value="<?php echo $row['age']?>"required>
        <button type="submit" name="update">Update</button>
    </form>
    <?php endif; ?>
</body>
</html>